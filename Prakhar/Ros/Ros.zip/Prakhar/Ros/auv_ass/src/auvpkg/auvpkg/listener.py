import rclpy
from rclpy.node import Node
from std_msgs.msg import String

class Listener(Node):
    def __init__(self):
        super().__init__('listener')
        # Subscribe to the 'chatter' topic with message type String
        self.subscription = self.create_subscription(
            String,  # Message type
            'chatter',  # Topic name
            self.listener_callback,  # Callback function
            10  # QoS history depth
        )
        self.subscription  # To prevent unused variable warning

    def listener_callback(self, msg):
        # Log the received message to the terminal
        self.get_logger().info(f'Received: "{msg.data}"')

def main(args=None):
    rclpy.init(args=args)  # Initialize ROS 2 communication
    node = Listener()  # Create Listener node
    rclpy.spin(node)  # Keep the node running
    node.destroy_node()  # Clean up after node shuts down
    rclpy.shutdown()  # Shutdown ROS 2 communication

if __name__ == '__main__':
    main()
