import os
from glob import glob
from setuptools import setup

package_name = 'my_talker_listener'

setup(
    name=package_name,
    version='0.0.0',
    packages=[package_name],
    data_files=[
        ('share/ament_index/resource_index/packages',
            ['resource/' + package_name]),
        ('share/' + package_name, ['package.xml']),
        (os.path.join('share', package_name, 'launch'), glob('launch/*.py')),
    ],
    install_requires=['setuptools'],
    zip_safe=True,
    maintainer='ayushm2048',
    maintainer_email='ayushm2048@todo.todo',
    description='Talker and Listener nodes',
    license='MIT',
    entry_points={
        'console_scripts': [
            'talker = my_talker_listener.talker:main',
            'listener = my_talker_listener.listener:main',
        ],
    },
)
