from launch import LaunchDescription
from launch_ros.actions import Node
from launch.substitutions import LaunchConfiguration
from launch.actions import DeclareLaunchArgument

def generate_launch_description():
    return LaunchDescription([
        DeclareLaunchArgument(
            'message',
            default_value='Hello from launch file!',
            description='Message to be published by talker'
        ),

        Node(
            package='my_talker_listener',
            executable='talker',
            name='talker',
            parameters=[{'msg': LaunchConfiguration('message')}]
        ),

        Node(
            package='my_talker_listener',
            executable='listener',
            name='listener'
        ),
    ])
